<?php

    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "webent";

    $koneksi = mysqli_connect($server, $username, $password, $database) or die ("Koneksi Gagal");

?>