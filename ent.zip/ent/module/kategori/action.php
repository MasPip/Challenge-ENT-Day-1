<?php
include_once("../../function/helper.php");
include_once("../../function/connection.php");

$button = isset($_POST['button']) ? $_POST['button'] : $_GET['button'];
$kategori_id = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : "";

$kategori_nama = isset($_POST['kategori_nama']) ? $_POST['kategori_nama'] : "";

if ($button == "Add") {
  if (empty($kategori_nama)) {
    echo "<script>alert('Mohon isi semua data yang diperlukan!');</script>";
    echo "<script>window.location.href = '".BASE_URL."index.php?page=my_profile&module=kategori&action=form';</script>";
  } else {
    $statement = $koneksi->prepare("INSERT INTO kategori (kategori_nama) VALUES (?)");
    $statement->bind_param('s', $kategori_nama);
    $statement->execute();
    echo "<script>alert('Data berhasil ditambahkan!');</script>";
    echo "<script>window.location.href = '".BASE_URL."index.php?page=my_profile&module=kategori&action=list';</script>";
  }
}

if ($button == "Update") {
  if (empty($kategori_nama)) {
    echo "<script>alert('Mohon isi semua data yang diperlukan!');</script>";
    echo "<script>window.location.href = '".BASE_URL."index.php?page=my_profile&module=kategori&action=form&kategori_id=$kategori_id';</script>";
  } else {
    $statement = $koneksi->prepare("UPDATE kategori SET kategori_nama=? WHERE kategori_id=?");
    $statement->bind_param('si', $kategori_nama, $kategori_id);
    $statement->execute();
    echo "<script>alert('Data berhasil diupdate!');</script>";
    echo "<script>window.location.href = '".BASE_URL."index.php?page=my_profile&module=kategori&action=list';</script>";
  }
}

if ($button == "Delete") {
  mysqli_query($koneksi, "DELETE FROM kategori WHERE kategori_id='$kategori_id'");
  echo "<script>alert('Data berhasil dihapus!');</script>";
  echo "<script>window.location.href = '".BASE_URL."index.php?page=my_profile&module=kategori&action=list';</script>";
}
?>