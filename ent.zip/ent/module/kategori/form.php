<?php
$kategori_id = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : false;

$kategori_nama = "";
$button = "Add";

if ($kategori_id) {
  $queryKategori = mysqli_query($koneksi, "SELECT * FROM kategori WHERE kategori_id='$kategori_id'");
  $row = mysqli_fetch_assoc($queryKategori);

  $kategori_nama = $row['kategori_nama'];
  $button = "Update";
}
?>

<div class="container">
  <h2>Form Kategori</h2>
  <form action="<?php echo BASE_URL . "module/kategori/action.php?kategori_id=$kategori_id" ?>" method="post">
    <div class="form-group">
      <label for="kategori_nama">Nama Kategori</label>
      <input type="text" name="kategori_nama" value="<?php echo $kategori_nama; ?>" class="form-control" placeholder="Masukkan nama kategori">
    </div>
    <button type="submit" name="button" value="<?php echo $button; ?>" class="btn btn-primary">Simpan</button>
  </form>
</div>