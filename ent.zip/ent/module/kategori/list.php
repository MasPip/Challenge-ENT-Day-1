<div class="action">
  <h3>Daftar Kategori</h3>
</div>

<div id="frame-tambah" class="d-lg-flex justify-content-lg-end my-2">
  <a class='btn btn-primary' href="<?php echo BASE_URL."index.php?page=my_profile&module=kategori&action=form"?>">+ Tambah Kategori</a>
</div>

<?php

  $queryKategori = mysqli_query($koneksi, "SELECT * FROM kategori");

  if(mysqli_num_rows($queryKategori) == 0){
    echo "<p>Tidak ada data</p>";
  } else { 
    echo "<table class='table'>";
    echo "<thead class='thead-dark'>";
    echo "<tr>
    <th scope='col'>No</th>
    <th scope='col'>Nama Kategori</th>
    <th scope='col'>Action</th>
    </tr>";
    echo "</thead>";
    
    $no = 1;

    while($row = mysqli_fetch_assoc($queryKategori)){
      echo "<tr>
      <th scope='row'>$no</th>
      <td style='font-size: 18px;'><b>$row[kategori_nama]</b></td>
      <td>
      <a class='btn btn-primary' href='".BASE_URL."index.php?page=my_profile&module=kategori&action=form&kategori_id=$row[kategori_id]'>Edit</a>
      <a class='btn btn-danger' href='#' onclick='hapusData($row[kategori_id])'>Delete</a>
      </td>
      </tr>";

      $no++;
    }
    echo "</table>";
  }

?>

<script>
function hapusData(id) {
  if (confirm("Yakin ingin menghapus data?")) {
    window.location.href = "<?php echo BASE_URL ?>module/kategori/action.php?button=Delete&kategori_id=" + id;
  }
}
</script>