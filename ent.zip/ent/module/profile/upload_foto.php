<?php
    if(isset($_FILES['foto'])){
        $foto = $_FILES['foto'];
        $user_id = $_POST['user_id'];


        $queryCek = mysqli_query($koneksi, "SELECT * FROM user WHERE user_id='$user_id' AND foto!=''");
        if(mysqli_num_rows($queryCek) > 0){
   
            $rowCek = mysqli_fetch_assoc($queryCek);
            unlink('img/profile/'.$rowCek['foto']);
        }


        $namaFile = $foto['name'];
        $tmpName = $foto['tmp_name'];
        $size = $foto['size'];
        $type = $foto['type'];

 
        if($type == 'image/jpeg' || $type == 'image/png'){

            move_uploaded_file($tmpName, 'img/profile/'.$namaFile);

            $queryUpdate = mysqli_query($koneksi, "UPDATE user SET foto='$namaFile' WHERE user_id='$user_id'");

            header("location:". BASE_URL. "index.php?page=profile_user");
        } else {
            echo "File foto tidak valid";
        }
    }
?>