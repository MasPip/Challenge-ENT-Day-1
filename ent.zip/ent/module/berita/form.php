<?php

    $berita_id = isset($_GET['berita_id']) ? $_GET['berita_id'] : false;

    $judul = "";
    $isi = "";
    $kategori = "";
    $gambar = "";
    $button = "Add";

    if($berita_id){
        $queryPos = mysqli_query($koneksi, "SELECT * FROM berita WHERE berita_id='$berita_id'");
        $row = mysqli_fetch_assoc($queryPos);

        $judul = $row['judul'];
        $isi = $row['isi'];
        $kategori = $row['kategori'];
        $gambar = $row['gambar'];
        $button = "Update";
    }

    $queryKategori = mysqli_query($koneksi, "SELECT * FROM kategori");
    $kategoriOption = "";
    while($rowKategori = mysqli_fetch_assoc($queryKategori)){
        $kategoriOption .= "<option value='".$rowKategori['kategori_id']."'>".$rowKategori['kategori_nama']."</option>";
    }

?>

<div class="container">
    <h2>Form Berita</h2>
    <form action="<?php echo BASE_URL . "module/berita/action.php?berita_id=$berita_id" ?>" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="judul">Judul</label>
            <input type="text" name="judul" value="<?php echo $judul; ?>" class="form-control" placeholder="Masukkan judul berita">
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>
            <select name="kategori" class="form-control">
                <?php 
                    mysqli_data_seek($queryKategori, 0); 
                    while($rowKategori = mysqli_fetch_assoc($queryKategori)){
                        if($kategori == $rowKategori['kategori_id']){
                            echo "<option value='".$rowKategori['kategori_id']."' selected>".$rowKategori['kategori_nama']."</option>";
                        } else {
                            echo "<option value='".$rowKategori['kategori_id']."'>".$rowKategori['kategori_nama']."</option>";
                        }
                    }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="isi">Isi</label>
            <textarea name="isi" cols="100" rows="10" class="form-control" placeholder="Masukkan isi berita"><?php echo $isi; ?></textarea>
        </div>
        <div class="form-group">
            <label for="file">Gambar</label>
            <input type="file" name="file" id="file" class="form-control-file">
            <img id="preview" src="" >
            <?php if($gambar) : ?>
                <img id="old-preview" src="<?php echo BASE_URL . "img/berita/$gambar"; ?>">
            <?php endif; ?>
        </div>

        <script>
            const fileInput = document.getElementById('file');
            const preview = document.getElementById('preview');
            const oldPreview = document.getElementById('old-preview');

            fileInput.addEventListener('change', (e) => {
                const file = fileInput.files[0];
                const reader = new FileReader();

                reader.onload = (e) => {
                    preview.src = e.target.result;
                    if (oldPreview) {
                        oldPreview.style.display = 'none';
                    }
                };

                reader.readAsDataURL(file);
            });
        </script>
        <button type="submit" name="button" value="<?php echo $button; ?>" class="btn btn-primary">Simpan</button>
    </form>
</div>