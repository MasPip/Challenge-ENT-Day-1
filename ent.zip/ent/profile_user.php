<?php

    if (empty($user_id)) {
        header("location: index.php");
    }

    if (isset($_POST['edit_profil'])) {
        $user_id = $_POST['user_id'];
        $nama = $_POST['nama'];
        $email = $_POST['email'];

        $queryUpdate = mysqli_query($koneksi, "UPDATE user SET nama='$nama', email='$email' WHERE user_id='$user_id'");
        if ($queryUpdate) {
            echo "<script>alert('Data berhasil diupdate'); window.location.href='?page=profile_user';</script>";
        } else {
            echo "<script>alert('Gagal mengupdate data'); window.location.href='?page=profile_user';</script>";
        }
    }

    $queryUser = mysqli_query($koneksi, "SELECT * FROM user WHERE user_id='$user_id'");
    $row = mysqli_fetch_assoc($queryUser);

?>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <h5 class="card-header">Foto Profil</h5>
                <div class="card-body">
                    <?php
                    if($row['foto'] != ''){
                        echo "<img src='".BASE_URL."img/profile/$row[foto]' class='img-fluid rounded-circle' width='200' height='200'>";
                    } else {
                        echo "Belum ada foto profil";
                    }
                    ?>
                    <form action="?page=my_profile&module=profile&action=upload_foto" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="user_id" value="<?= $user_id ?>">
                        <input type="file" name="foto" class="form-control mt-2">
                        <button type="submit" class="btn btn-primary mt-3">Upload Foto</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <h5 class="card-header">Informasi Profil</h5>
                <div class="card-body">
                    <form action="" method="post">
                        <input type="hidden" name="user_id" value="<?= $user_id ?>">
                        <div class="form-group">
                            <label for="nama">Nama User</label>
                            <input type="text" class="form-control" id="nama" name="nama" value="<?= $row['nama'] ?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= $row['email'] ?>">
                        </div>
                        <button type="submit" name="edit_profil" class="btn btn-primary mt-3">Simpan Perubahan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>