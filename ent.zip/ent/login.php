<?php

if($user_id){
    header("location: ".BASE_URL."index.php?page=my_profile&module=berita&action=list");
}

?>

<div class="container">
    <div class="row">
        <div class="user-login col-lg-12">
            <form action="<?php echo "login_process.php"; ?>" method="post">
                <?php
                $notif = isset($_GET['notif']) ? $_GET['notif'] : false;

                if($notif == "true"){
                    echo "<script>alert('Username & Password tidak ada');</script>";
                }

                ?>
                <div class="form-body">
                    <label for="email">Email</label>
                    <input type="email" name="email">
                </div>
                <div class="form-body">
                    <label for="password">Password</label>
                    <input type="password" name="password">
                </div>
                <input class="btn btn-primary my-2" type="submit" value="Login">
            </form>
        </div>
    </div>
</div>