<?php
if($user_id){
    header("location: ".BASE_URL."index.php?page=my_profile&module=berita&action=list");
}
?>

<div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-md-9 col-lg-6 col-xl-5">
            <img src="assets/img/draw2.webp" class="img-fluid" alt="Sample image">
        </div>
        <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
            <form action="<?php echo "login_process.php"; ?>" method="post">
                <?php
                $notif = isset($_GET['notif']) ? $_GET['notif'] : false;

                if($notif == "true"){
                    echo "<div class='alert alert-danger'>Username & Password tidak ada</div>";
                }
                ?>
                <div class="form-outline mb-4">
                    <label for="email">Email</label>
                    <input type="email" name="email" class="form-control form-control-lg" placeholder="Masukkan email Anda">
                </div>
                <div class="form-outline mb-3">
                    <label for="password">Password</label>
                    <input type="password" name="password" class="form-control form-control-lg" placeholder="Masukkan password Anda">
                </div>
                <div class="text-center text-lg-start mt-4 pt-2">
                    <input class="btn btn-primary btn-lg" style="padding-left: 2.5rem; padding-right: 2.5rem;" type="submit" value="Login">
                    <p class="small fw-bold mt-2 pt-1 mb-0">Belum punya akun? <a href="http://localhost/ent/index.php?page=register" class="link-danger">Register</a></p>
                </div>
            </form>
        </div>
    </div>
</div>